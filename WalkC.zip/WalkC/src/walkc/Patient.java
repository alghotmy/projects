package walkc;


import java.time.LocalDate;
import java.time.Period;
import javafx.beans.property.SimpleStringProperty;
import javafx.scene.image.Image;
/**
 * <p>
 */
public class Patient
{
   private SimpleStringProperty firstName, lastName, address, telephoneNumber, emergencyContact, emergencyNumber, healthInsurance, bloodType, familyDoctor, gP, clinicDoctor, code, weight, height, notes;
   private LocalDate dob;
   private Image photo;

   public Patient (String firstName, String lastName, String address, String telephoneNumber, String emergencyContact, String emergencyNumber, String healthInsurance, String bloodType, String familyDoctor, String gP, String clinicDoctor, String code, String weight, String height, String notes, LocalDate dob, Image photo)
   {
      this.firstName = new SimpleStringProperty(firstName);
      this.lastName = new SimpleStringProperty(lastName);
      this.address = new SimpleStringProperty(address);
      this.telephoneNumber = new SimpleStringProperty(telephoneNumber);
      this.emergencyContact = new SimpleStringProperty(emergencyContact);
      this.emergencyNumber = new SimpleStringProperty(emergencyNumber);
      this.healthInsurance = new SimpleStringProperty(healthInsurance);
      this.bloodType = new SimpleStringProperty(bloodType);
      this.familyDoctor = new SimpleStringProperty(familyDoctor);
      this.gP = new SimpleStringProperty(gP);
      this.clinicDoctor = new SimpleStringProperty(clinicDoctor);
      this.code = new SimpleStringProperty(code);
      this.weight = new SimpleStringProperty(weight);
      this.height = new SimpleStringProperty(height);
      this.notes = new SimpleStringProperty(notes);
      this.dob = dob;
      this.photo = photo;
   }

   /**
    *
    * @param firstName
    * @param lastName
    * @param address
    * @param telephoneNumber
    * @param emergencyContact
    * @param emergencyNumber
    * @param healthInsurance
    * @param bloodType
    * @param familyDoctor
    * @param gP
    * @param clinicDoctor
    * @param code
    * @param weight
    * @param height
    * @param notes
    * @param dob
    */
   public Patient (String firstName, String lastName, String address, String telephoneNumber, String emergencyContact, String emergencyNumber, String healthInsurance, String bloodType, String familyDoctor, String gP, String clinicDoctor, String code, String weight, String height, String notes, LocalDate dob)
   {
      this.firstName = new SimpleStringProperty(firstName);
      this.lastName = new SimpleStringProperty(lastName);
      this.address = new SimpleStringProperty(address);
      this.telephoneNumber = new SimpleStringProperty(telephoneNumber);
      this.emergencyContact = new SimpleStringProperty(emergencyContact);
      this.emergencyNumber = new SimpleStringProperty(emergencyNumber);
      this.healthInsurance = new SimpleStringProperty(healthInsurance);
      this.bloodType = new SimpleStringProperty(bloodType);
      this.familyDoctor = new SimpleStringProperty(familyDoctor);
      this.gP = new SimpleStringProperty(gP);
      this.clinicDoctor = new SimpleStringProperty(clinicDoctor);
      this.code = new SimpleStringProperty(code);
      this.weight = new SimpleStringProperty(weight);
      this.height = new SimpleStringProperty(height);
      this.notes = new SimpleStringProperty(notes);
      this.dob = dob;
      photo = new Image("defaultImage.png");
   }

   public String getFirstName ()
   {
      return firstName.get();
   }

   public String getLastName ()
   {
      return lastName.get();
   }

   public String getAddress ()
   {
      return address.get();
   }

   public String getTelephoneNumber ()
   {
      return telephoneNumber.get();
   }

   public String getEmergencyContact ()
   {
      return emergencyContact.get();
   }

   public String getEmergencyNumber ()
   {
      return emergencyNumber.get();
   }

   public String getHealthInsurance ()
   {
      return healthInsurance.get();
   }

   public String getBloodType ()
   {
      return bloodType.get();
   }

   public String getFamilyDoctor ()
   {
      return familyDoctor.get();
   }

   public String getgP ()
   {
      return gP.get();
   }

   public String getClinicDoctor ()
   {
      return clinicDoctor.get();
   }

   public String getCode ()
   {
      return code.get();
   }

   public String getWeight ()
   {
      return weight.get();
   }

   public String getHeight ()
   {
      return height.get();
   }

   public String getNotes ()
   {
      return notes.get();
   }

   public LocalDate getDob ()
   {
      return dob;
   }

   public Image getPhoto ()
   {
      return photo;
   }

   public int getAge ()
   {
      return Period.between(dob, LocalDate.now()).getYears();
   }

   public void setFirstName (String firstName)
   {
      this.firstName = new SimpleStringProperty(firstName);
   }

   public void setLastName (String lastName)
   {
      this.lastName = new SimpleStringProperty(lastName);
   }

   public void setAddress (String address)
   {
      this.address = new SimpleStringProperty(address);
   }

   public void setTelephoneNumber (String telephoneNumber)
   {
      this.telephoneNumber = new SimpleStringProperty(telephoneNumber);
   }

   public void setEmergencyContact (String emergencyContact)
   {
      this.emergencyContact = new SimpleStringProperty(emergencyContact);
   }

   public void setEmergencyNumber (String emergencyNumber)
   {
      this.emergencyNumber = new SimpleStringProperty(emergencyNumber);
   }

   public void setHealthInsurance (String healthInsurance)
   {
      this.healthInsurance = new SimpleStringProperty(healthInsurance);
   }

   public void setBloodType (String bloodType)
   {
      this.bloodType = new SimpleStringProperty(bloodType);
   }

   public void setFamilyDoctor (String familyDoctor)
   {
      this.familyDoctor = new SimpleStringProperty(familyDoctor);
   }

   public void setgP (String gP)
   {
      this.gP = new SimpleStringProperty(gP);
   }

   public void setClinicDoctor (String clinicDoctor)
   {
      this.clinicDoctor = new SimpleStringProperty(clinicDoctor);
   }

   public void setCode (String code)
   {
      this.code = new SimpleStringProperty(code);
   }

   public void setWeight (String weight)
   {
      this.weight = new SimpleStringProperty(weight);
   }

   public void setHeight (String height)
   {
      this.height = new SimpleStringProperty(height);
   }

   public void setNotes (String notes)
   {
      this.notes = new SimpleStringProperty(notes);
   }

   public void setDob (LocalDate dob)
   {
      this.dob = dob;
   }

   public void setPhoto (Image photo)
   {
      this.photo = photo;
   }

   public String toString ()
   {
      return String.format("%s %s", firstName, lastName);
   }

   public String ToFile ()
   {
      return String.format("%s~%s~%s~%s~%s~%s~%s~%s~%s~%s~%s~%s~%s~%s~%s~%s\n", this.getFirstName(), this.getLastName(), this.getAddress(), this.getTelephoneNumber(), this.getEmergencyContact(), this.getEmergencyNumber(), this.getHealthInsurance(), this.getBloodType(), this.getFamilyDoctor(), this.getgP(), this.getClinicDoctor(), this.getCode(), this.getWeight(), this.getHeight(), this.getNotes(), this.getDob());
   }


}
