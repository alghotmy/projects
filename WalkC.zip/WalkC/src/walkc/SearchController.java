/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package walkc;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Al
 */
public class SearchController implements Initializable
{
   protected Patient newPateint;
   //configure the table
   @FXML
   protected TableView<Patient> tableView;
   @FXML
   protected TableColumn<Patient, String> firstNameColumn;
   @FXML
   protected TableColumn<Patient, String> lastNameColumn;
   @FXML
   protected TableColumn<Patient, String> addressColumn;
   @FXML
   protected TableColumn<Patient, String> telephoneColumn;
   @FXML
   protected TableColumn<Patient, String> emergencyContactColumn;
   @FXML
   protected TableColumn<Patient, String> emergencyNumberColumn;
   @FXML
   protected TableColumn<Patient, String> healthInsuranceColumn;
   @FXML
   protected TableColumn<Patient, String> bloodTypeColumn;
   @FXML
   protected TableColumn<Patient, String> familyDoctorColumn;
   @FXML
   protected TableColumn<Patient, String> gpColumn;
   @FXML
   protected TableColumn<Patient, String> clinicDoctorColumn;
   @FXML
   protected TableColumn<Patient, String> codeColumn;
   @FXML
   protected TableColumn<Patient, String> notesColumn;
   @FXML
   protected TableColumn<Patient, String> weightColumn;
   @FXML
   protected TableColumn<Patient, String> heightColumn;
   @FXML
   protected TableColumn<Patient, LocalDate> dobColumn;
   ObservableList<Patient> patientsFile;

   protected String FieldDelimiter = ",";

   protected BufferedReader br;


   /**
    * Initializes the controller class.
    *
    * @param event
    * @throws java.io.IOException
    */

   @FXML
   public void backToMain (ActionEvent event) throws IOException
   {


      Parent root = FXMLLoader.load(getClass().getResource("Landing.fxml"));

      Scene searchScene = new Scene(root);
      //Stage stage = new Stage();
      Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
      stage.setScene(searchScene);
      stage.show();


   }

   public void initData (ObservableList patients)
   {
      //newPateint = patient;
//      firstNameColumn.setText(newPateint.getFirstName());
//      lastNameColumn.setText(newPateint.getLastName());
//      addressColumn.setText(newPateint.getAddress());
//      telephoneColumn.setText(newPateint.getTelephoneNumber());
//      emergencyContactColumn.setText(newPateint.getEmergencyContact());
//      emergencyNumberColumn.setText(newPateint.getEmergencyContact());
//      healthInsuranceColumn.setText(newPateint.getHealthInsurance());
//      bloodTypeColumn.setText(newPateint.getBloodType());
//      familyDoctorColumn.setText(newPateint.getFamilyDoctor());
//      gpColumn.setText(newPateint.getgP());
//      clinicDoctorColumn.setText(newPateint.getClinicDoctor());
//      codeColumn.setText(newPateint.getCode());
//      notesColumn.setText(newPateint.getNotes());
//      weightColumn.setText(newPateint.getWeight());
//      heightColumn.setText(newPateint.getHeight());
//      dobColumn.setText(Integer.toString(newPateint.getAge()));
      patientsFile = FXCollections.observableArrayList();

      tableView.setItems(patientsFile);
      //tableView.getItems().addAll(patients);
      readFile();




   }


   public void goToNew (ActionEvent event) throws IOException
   {


      Parent root = FXMLLoader.load(getClass().getResource("AddNew.fxml"));

      Scene scene = new Scene(root);
      //Stage stage = new Stage();
      Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
      stage.setScene(scene);
      stage.show();


   }

   public TableView<Patient> getTableView ()
   {
      return tableView;
   }

   public void setTableView (TableView<Patient> tableView)
   {
      this.tableView = tableView;
   }

   public void readFile ()
   {

      String File = "clinic.txt";
      String FieldDelimiter = "~";

      BufferedReader br;

      FileReader fileReader = null;
      try {
         fileReader = new FileReader(File);
         br = new BufferedReader(fileReader);

         String line;
         while ((line = br.readLine()) != null) {
            if (!line.trim().isEmpty()) {
               String[] fields = line.split(FieldDelimiter);

               DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
               LocalDate date = LocalDate.parse(fields[15], dtf);

               System.out.println(line);
               newPateint = new Patient(fields[0], fields[1], fields[2],
                                        fields[3], fields[4], fields[5], fields[6], fields[7], fields[8],
                                        fields[9], fields[10], fields[11], fields[12], fields[13], fields[14],
                                        date);
               patientsFile.add(newPateint);
               System.out.println(newPateint.ToFile());
            }
         }



      }
      catch (Exception ex) {
         System.out.println("file not found");
         if (fileReader != null) {
            try {
               fileReader.close();
            }
            catch (IOException ex1) {

            }
         }

      }



   }


   @Override
   public void initialize (URL url, ResourceBundle rb)
   {
      //set up the columns in the table


      firstNameColumn.setCellValueFactory(new PropertyValueFactory("firstName"));
      lastNameColumn.setCellValueFactory(new PropertyValueFactory<Patient, String>("lastName"));
      dobColumn.setCellValueFactory(new PropertyValueFactory<Patient, LocalDate>("dob"));
      addressColumn.setCellValueFactory(new PropertyValueFactory("address"));
      telephoneColumn.setCellValueFactory(new PropertyValueFactory<Patient, String>("telephoneNumber"));
      emergencyContactColumn.setCellValueFactory(new PropertyValueFactory<Patient, String>("emergencyContact"));
      emergencyNumberColumn.setCellValueFactory(new PropertyValueFactory("emergencyNumber"));
      healthInsuranceColumn.setCellValueFactory(new PropertyValueFactory<Patient, String>("healthInsurance"));
      bloodTypeColumn.setCellValueFactory(new PropertyValueFactory<Patient, String>("bloodType"));
      familyDoctorColumn.setCellValueFactory(new PropertyValueFactory("familyDoctor"));
      gpColumn.setCellValueFactory(new PropertyValueFactory<Patient, String>("gP"));
      clinicDoctorColumn.setCellValueFactory(new PropertyValueFactory<Patient, String>("clinicDoctor"));
      codeColumn.setCellValueFactory(new PropertyValueFactory("code"));
      notesColumn.setCellValueFactory(new PropertyValueFactory<Patient, String>("weight"));
      weightColumn.setCellValueFactory(new PropertyValueFactory<Patient, String>("height"));
      heightColumn.setCellValueFactory(new PropertyValueFactory<Patient, String>("notes"));
      tableView.setEditable(true);
      firstNameColumn.setCellFactory(TextFieldTableCell.forTableColumn());

   }

   public void changeFirstNameCellEvent (TableColumn.CellEditEvent edittedCell)
   {
      Patient patientSelected = tableView.getSelectionModel().getSelectedItem();
      patientSelected.setFirstName(edittedCell.getNewValue().toString());
   }


}
