package walkc;
/**
 * @author Rich Smith at ZenOfProgramming.com
 */
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.*;
import java.util.Scanner;
import javafx.collections.ObservableList;

public class MyFile
{

   protected FileWriter x;
   protected Scanner s;



   /* public void openFile ()
    * {
    *
    * try {
    * x = new FileWriter(new File("clinic.txt"), true);
    * s = new Scanner("clinic.txt");
    *
    * }
    * catch (Exception e) {
    * System.out.println("You have an error");
    * }
    *
    *
    *
    * @param patient
    *
    * }
    *
    * public void addRecoreds (Patient patient) throws IOException
    * {
    * x.write(patient.ToFile());
    * x.write(System.lineSeparator());
    * }
    *
    * public void closeFile () throws IOException
    * {
    * x.close();
    * }
    *
    * //public void readFile(TableView table){
    * // while(s.hasNext()){
    * // String a = s.next();
    */
   protected void printObservableListToFile (ObservableList<Patient> List, String filename) throws IOException
   {
      try (PrintWriter writer = new PrintWriter(new FileOutputStream(new File(filename), true))) {
         for (Patient line : List) {
            writer.println(line.ToFile());
            writer.write(System.lineSeparator());
         }
         writer.close();
      }
      catch (Exception e) {
         System.out.println(e.getMessage());
      }

   }

   public void closeFile () throws IOException
   {
      s.close();
   }

}
