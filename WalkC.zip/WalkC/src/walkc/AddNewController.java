/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package walkc;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Al
 */
public class AddNewController implements Initializable
{
//These instance variables are used to create new Patient objects
   @FXML
   private TextField firstNameTextField;
   @FXML
   private TextField lastNameTextField;
   @FXML
   private DatePicker birthdayDatePicker;
   @FXML
   private TextField addressTextField;
   @FXML
   private TextField telephoneTextField;
   @FXML
   private TextField emergencyContactTextField;
   @FXML
   private TextField emergencyNumberTextField;
   @FXML
   private TextField healthInsuranceTextField;
   @FXML
   private TextField bloodTypeTextField;
   @FXML
   private TextField familyDoctorTextField;
   @FXML
   private TextField gpTextField;
   @FXML
   private TextField clinicTextField;
   @FXML
   private TextField codeTextField;
   @FXML
   private TextArea noteTextField;
   @FXML
   private TextField weightTextField;
   @FXML
   private TextField heightTextField;
   MyFile f = new MyFile();
   SearchController search = new SearchController();
   ObservableList<Patient> patients = FXCollections.observableArrayList();


   /**
    *
    * @param event
    * @throws IOException
    */
   @FXML
   public void backToMain (ActionEvent event) throws IOException
   {


      Parent root = FXMLLoader.load(getClass().getResource("Landing.fxml"));

      Scene scene = new Scene(root);
      //Stage stage = new Stage();
      Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
      stage.setScene(scene);
      stage.show();


   }

//

   public void addNew (ActionEvent e) throws IOException
   {

      //ObservableList<Patient> patients = FXCollections.observableArrayList();
      FXMLLoader loader = new FXMLLoader();
      loader.setLocation(getClass().getResource("Search.fxml"));
      Parent root = loader.load();
      Scene searchScene = new Scene(root);

      SearchController controller = loader.getController();


      Patient patient = new Patient(firstNameTextField.getText(), lastNameTextField.getText(), addressTextField.getText(), telephoneTextField.getText(), emergencyContactTextField.getText(), emergencyNumberTextField.getText(), healthInsuranceTextField.getText(), bloodTypeTextField.getText(), familyDoctorTextField.getText(), gpTextField.getText(), clinicTextField.getText(), codeTextField.getText(), weightTextField.getText(), heightTextField.getText(), noteTextField.getText(), birthdayDatePicker.getValue());

      patients.add(patient);
      f.printObservableListToFile(patients, "clinic.txt");
      controller.initData(patients);



      //   f.openFile();
      //  f.addRecoreds(patient);
      // f.x.format("%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s", firstNameTextField.getText(), lastNameTextField.getText(), addressTextField.getText(), telephoneTextField.getText(), emergencyContactTextField.getText(), emergencyNumberTextField.getText(), healthInsuranceTextField.getText(), bloodTypeTextField.getText(), familyDoctorTextField.getText(), gpTextField.getText(), clinicTextField.getText(), codeTextField.getText(), weightTextField.getText(), heightTextField.getText(), noteTextField.getText(), birthdayDatePicker.getValue());

//      f.closeFile();

      Stage window = (Stage) ((Node) e.getSource()).getScene().getWindow();

      window.setScene(searchScene);
      window.show();



      //  Patient newPatient = (new Patient(firstNameTextField.getText(), lastNameTextField.getText(), addressTextField.getText(), telephoneTextField.getText(), emergencyContactTextField.getText(), emergencyNumberTextField.getText(), healthInsuranceTextField.getText(), bloodTypeTextField.getText(), familyDoctorTextField.getText(), gpTextField.getText(), clinicTextField.getText(), codeTextField.getText(), weightTextField.getText(), heightTextField.getText(), noteTextField.getText(), birthdayDatePicker.getValue()));

      //SearchController search = new SearchController();
      //  patients.add(newPatient);
      // search.initialize(null, null);
      // search.tableView.setItems(patients);

      //access the controller and call a method
      // SearchController controller = loader.getController();
      //controller.initData(tableView.getSelectionModel().getSelectedItem());
   }

////
////
////
////
////      //   Parent root = FXMLLoader.load(getClass().getResource("Added.fxml"));
////
////      //Scene scene = new Scene(root);
////      //Stage stage = new Stage();
////      //   Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
////      //   stage.setScene(scene);
////      //  stage.show();
////   }

   /**
    * Initializes the controller class.
    */



   @Override
   public void initialize (URL url, ResourceBundle rb)
   {
      // TODO

   }
}
