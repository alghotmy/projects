package com.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Product
 */
@WebServlet("/Product")
public class Product extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Connection con;
	PreparedStatement pstView;
	PreparedStatement pstUpdate;
	PreparedStatement pstInsert;
	PreparedStatement pstAll;
	ResultSet rs;
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Product() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		 String connectionUrl = "jdbc:mysql://localhost:3305/product";
		 String connectionUser = "root";
		 String connectionPassword = "admin";
		 String insertQuery = "Insert into product (productID,productName,quantity,price,category) values (?,?,?,?,?)";
		 String viewQuery="SELECT * from product where productID=?";
		 String updateQuery="Update product set productName=?,quantity=?,price=?,category=? where productID=?";
		 String allQuery="select * from product";
		 String button = request.getParameter("button");
		 
		 if ("update".equals(button)) {
		 try{
	    	   
	    	 int productID=Integer.parseInt(request.getParameter("productID"));
	    	 String productName= request.getParameter("productName");
	    	 int quantity= Integer.parseInt(request.getParameter("quantity"));
	    	 float price=Float.parseFloat(request.getParameter("price"));
	    	 String category= request.getParameter("category");
	    	 
			 Class.forName("com.mysql.jdbc.Driver").newInstance();     
			 con = DriverManager.getConnection(connectionUrl, connectionUser, connectionPassword);
					
	 		 pstUpdate=con.prepareStatement(updateQuery);
			
			 pstUpdate.setString(1, productName);
			 pstUpdate.setInt(2,quantity);
			 pstUpdate.setFloat(3,price);
			 pstUpdate.setString(4, category);
			 pstUpdate.setInt(5,productID);
			 
	         int r=pstUpdate.executeUpdate();
	         
	         out.println("Product has been updated to the below values");
	        
	         pstView=con.prepareStatement(viewQuery);
			 pstView.setInt(1,productID);
	         rs=pstView.executeQuery();
	         
	        out.println("<!doctype html><html>");
	  		out.println("<body><h2>Updated Product information List</h2>");
	  		   		    
	  		out.println("<table border=1>");
	  		out.println("<tr><th>Product ID</th><th>Name</th><th>Quantity</th><th>Price</th><th>Category</th></tr>");

	  		while(rs.next())
	  		 {
	  		    int productID1=rs.getInt("productID");
	  		    String productName1=rs.getString("productName");
	  		   int quantity1=rs.getInt("quantity");
	  		   float price1 =rs.getFloat("price");
	  		    String category1=rs.getString("category");
	  		    
	  out.println("<tr><td>"+productID1+"</td><td>"+productName1+"</td><td>"+quantity1+"</td><td>"+price1+"</td>"+"</td><td>"+category1+"</td>");
	 
	  		    
	  		 
	  		 
	  		 }
	  		
		 }
		 catch(SQLException e)
	       {
	    	  e.printStackTrace();
	       }
	       catch(ClassCastException e)
	       {
	    	   e.printStackTrace();
	       }
	       catch(Exception e)
	       {
	    	   e.printStackTrace();
	       }
		 }else if ("search".equals(button)) {
				 try{
					 int productID=Integer.parseInt(request.getParameter("productID"));
					 Class.forName("com.mysql.jdbc.Driver").newInstance();     
					 con = DriverManager.getConnection(connectionUrl, connectionUser, connectionPassword);
					 
					  pstView=con.prepareStatement(viewQuery);
					  pstView.setInt(1,productID);
				      rs=pstView.executeQuery();
				      out.println("Your search results have been retrieved!");
				      
				      out.println("<!doctype html><html>");
				  	  out.println("<body><h2>Search Results</h2>");
				  		   		    
				  	  out.println("<table border=1>");
				  	  out.println("<tr><th>Product ID</th><th>Name</th><th>Quantity</th><th>Price</th><th>Category</th></tr>");
				  	  
				  	while(rs.next())
			  		 {
			  		    int productID1=rs.getInt("productID");
			  		    String productName1=rs.getString("productName");
			  		   int quantity1=rs.getInt("quantity");
			  		   float price1 =rs.getFloat("price");
			  		    String category1=rs.getString("category");
			  		    
			  out.println("<tr><td>"+productID1+"</td><td>"+productName1+"</td><td>"+quantity1+"</td><td>"+price1+"</td>"+"</td><td>"+category1+"</td>");
			  
			  		     }
		  }
				 catch(SQLException e)
			       {
			    	  e.printStackTrace();
			       }
			       catch(ClassCastException e)
			       {
			    	   e.printStackTrace();
			       }
			       catch(Exception e)
			       {
			    	   e.printStackTrace();
			       }
	}else if ("add".equals(button)) {
		 try{
			 
		 int productID=Integer.parseInt(request.getParameter("productID"));
    	 String productName= request.getParameter("productName");
    	 int quantity= Integer.parseInt(request.getParameter("quantity"));
    	 float price=Float.parseFloat(request.getParameter("price"));
    	 String category= request.getParameter("category");
    	
			 
		 Class.forName("com.mysql.jdbc.Driver").newInstance();     
		 con = DriverManager.getConnection(connectionUrl, connectionUser, connectionPassword);
				
		 pstInsert=con.prepareStatement(insertQuery);
		 pstInsert.setInt(1,productID);
		 pstInsert.setString(2, productName);
		 pstInsert.setInt(3,quantity);
		 pstInsert.setFloat(4,price);
		 pstInsert.setString(5, category);
		 
		 int r=pstInsert.executeUpdate();
         
         out.println("Product has been added successfully");
         pstView=con.prepareStatement(viewQuery);
		 pstView.setInt(1,productID);
         rs=pstView.executeQuery();
         
        out.println("<!doctype html><html>");
  		out.println("<body><h2>New Product information </h2>");
  		   		    
  		out.println("<table border=1>");
  		out.println("<tr><th>Product ID</th><th>Name</th><th>Quantity</th><th>Price</th><th>Category</th></tr>");

  		while(rs.next())
  		 {
  		    int productID1=rs.getInt("productID");
  		    String productName1=rs.getString("productName");
  		   int quantity1=rs.getInt("quantity");
  		   float price1 =rs.getFloat("price");
  		    String category1=rs.getString("category");
  		    
  out.println("<tr><td>"+productID1+"</td><td>"+productName1+"</td><td>"+quantity1+"</td><td>"+price1+"</td>"+"</td><td>"+category1+"</td>");
  		    
 
  		 
  		 }
  		
	 }
	 catch(SQLException e)
       {
    	  e.printStackTrace();
       }
       catch(ClassCastException e)
       {
    	   e.printStackTrace();
       }
       catch(Exception e)
       {
    	   e.printStackTrace();
       }
	}else if ("all".equals(button)) {
		 try{
			 			 
		 Class.forName("com.mysql.jdbc.Driver").newInstance();     
		 con = DriverManager.getConnection(connectionUrl, connectionUser, connectionPassword);
				
		// int r=pstAll.executeUpdate();
        
        out.println("All information has been retrieved successfully");
       
        pstAll=con.prepareStatement(allQuery);
        rs=pstAll.executeQuery();
		
        
       out.println("<!doctype html><html>");
 		out.println("<body><h2>Product information List</h2>");
 		   		    
 		out.println("<table border=1>");
 		out.println("<tr><th>Product ID</th><th>Name</th><th>Quantity</th><th>Price</th><th>Category</th></tr>");

 		while(rs.next())
 		 {
 		    int productID1=rs.getInt("productID");
 		    String productName1=rs.getString("productName");
 		   int quantity1=rs.getInt("quantity");
 		   float price1 =rs.getFloat("price");
 		    String category1=rs.getString("category");
 		    
 out.println("<tr><td>"+productID1+"</td><td>"+productName1+"</td><td>"+quantity1+"</td><td>"+price1+"</td>"+"</td><td>"+category1+"</td>");
 		    

 		 
 		 }
 		
	 }
	 catch(SQLException e)
      {
   	  e.printStackTrace();
      }
      catch(ClassCastException e)
      {
   	   e.printStackTrace();
      }
      catch(Exception e)
      {
   	   e.printStackTrace();
      }
	} out.println("<a href=\"http://localhost:8080/ProdctForm/Product.html\" \">Click here to go back to home page </a>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
